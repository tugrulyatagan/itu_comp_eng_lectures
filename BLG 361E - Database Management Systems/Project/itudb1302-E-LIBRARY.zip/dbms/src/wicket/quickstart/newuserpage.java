package wicket.quickstart;

import java.util.Date;

import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.PasswordTextField;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.link.Link;

public class newuserpage extends BasePage {

	public newuserpage(User user) {
		/*
		 * UserControl kontrol = new UserControl(user); User person =
		 * kontrol.GetUser(); if (person != null) { Label name = new
		 * Label("name", person.getName()); Label surname = new Label("surname",
		 * person.getSurname()); this.add(name); this.add(surname); } else {
		 * Label name = new Label("name", "Wrong username or password"); Label
		 * surname = new Label("surname", ""); this.add(name);
		 * this.add(surname); }
		 */
	}

}